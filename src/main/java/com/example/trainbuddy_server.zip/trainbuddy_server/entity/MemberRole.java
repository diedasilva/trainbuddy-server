package com.example.trainbuddy_server.entity;

public enum MemberRole {
    ADMIN,
    COACH,
    MEMBER
}
