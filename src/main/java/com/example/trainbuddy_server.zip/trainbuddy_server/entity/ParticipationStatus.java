package com.example.trainbuddy_server.entity;

public enum ParticipationStatus {
    INVITED,
    JOINED,
    LEFT
}
