package com.example.trainbuddy_server.entity;

public enum Privacy {
    PUBLIC,
    PRIVATE
}