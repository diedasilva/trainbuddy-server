package com.example.trainbuddy_server.entity;

public enum Role {
    CLIENT,
    COACH,
    ADMIN
}
