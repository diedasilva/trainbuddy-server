package com.example.trainbuddy_server.entity;

public enum SessionStatus {
    PLANNED,
    COMPLETED,
    CANCELED
}
