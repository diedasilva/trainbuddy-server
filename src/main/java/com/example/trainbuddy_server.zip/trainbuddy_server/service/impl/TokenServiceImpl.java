package com.example.trainbuddy_server.service.impl;

import java.security.SecureRandom;
import java.time.Instant;
import java.util.Base64;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.trainbuddy_server.entity.RefreshToken;
import com.example.trainbuddy_server.entity.Users;
import com.example.trainbuddy_server.repository.RefreshTokenRepository;
import com.example.trainbuddy_server.security.JwtUtil;
import com.example.trainbuddy_server.service.TokenService;
import com.example.trainbuddy_server.service.UsersService;

/**
 * Implementation of TokenService for managing creation, rotation, and revocation
 * of refresh tokens.
 */
@Service
public class TokenServiceImpl implements TokenService {

    private final RefreshTokenRepository refreshRepo;
    private final UsersService usersService;
    private final JwtUtil jwtUtil;
    private final SecureRandom random = new SecureRandom();

    public TokenServiceImpl(RefreshTokenRepository refreshRepo,
                            UsersService usersService,
                            JwtUtil jwtUtil) {
        this.refreshRepo  = refreshRepo;
        this.usersService = usersService;
        this.jwtUtil      = jwtUtil;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public RefreshToken createRefreshToken(Long userId, String deviceId) {
        Users user = usersService.findById(userId)
            .orElseThrow(() -> new IllegalArgumentException("User not found: " + userId));

        String token = generateRandomToken();
        RefreshToken rt = new RefreshToken();
        rt.setToken(token);
        rt.setUser(user);
        rt.setDeviceId(deviceId);
        rt.setExpiresAt(Instant.now().plusMillis(jwtUtil.getRefreshExpiration()));
        // revokedAt remains null by default
        return refreshRepo.save(rt);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional
    public RefreshToken rotateRefreshToken(String oldToken) {
        RefreshToken existing = refreshRepo.findByTokenAndRevokedAtIsNull(oldToken)
            .orElseThrow(() -> new IllegalArgumentException("Invalid or revoked refresh token"));

        // Mark the old token as revoked
        existing.setRevokedAt(Instant.now());
        refreshRepo.save(existing);

        // Issue a new token with the same deviceId
        return createRefreshToken(existing.getUser().getId(), existing.getDeviceId());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional
    public void revokeRefreshToken(String token) {
        refreshRepo.findByTokenAndRevokedAtIsNull(token)
            .ifPresent(rt -> {
                rt.setRevokedAt(Instant.now());
                refreshRepo.save(rt);
            });
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Transactional
    public void revokeAllUserTokens(Long userId) {
        refreshRepo.deleteAllByUserId(userId);
    }

    /**
     * Generate a secure random token encoded in URL-safe Base64.
     *
     * @return a new random token string
     */
    private String generateRandomToken() {
        byte[] bytes = new byte[64];
        random.nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }
}
