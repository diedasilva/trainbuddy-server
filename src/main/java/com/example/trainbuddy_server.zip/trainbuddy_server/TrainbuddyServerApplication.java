package com.example.trainbuddy_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainbuddyServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(TrainbuddyServerApplication.class, args);
    }

}
